let subOpen = null;

document.querySelectorAll(".dropdown-item").forEach(item => {
    item.addEventListener("mouseenter", () => {
        let id = item.getAttribute("data-target");

        document.querySelectorAll(".sub-items").forEach(box => {
            box.style.display = "none";
        });

        let target = document.getElementById(id);
        target.style.display = "flex";
        subOpen = target;
    });
});

document.querySelectorAll(".sub-items").forEach(menu => {
    menu.addEventListener("mouseleave", () => {
        menu.style.display = "none";
        subOpen = null;
    });
});

document.querySelector(".navbar").addEventListener("mouseleave", () => {
    if (subOpen) subOpen.style.display = "none";
});


// ghulam
// ghulam
let products = [
  {
    img: "sli2.png",
    title: "Crompton Eliteo Curv Filterless Chimney"
  },
  {
    img: "sli3.png",
    title: "Crompton Energy Efficient Ceiling Fan"
  },
  {
    img: "sli4.png",
    title: "Crompton Rapid Jet Water Heater"
  },
  {
    img: "sli5.png",
    title: "Crompton Mixer Grinder"
  }
];

let index = 0;

function updateBig() {
  document.getElementById("bigImage").src = products[index].img;
  document.getElementById("bigTitle").innerText = products[index].title;
}

function changeProduct(i) {
  index = i;
  updateBig();
}

function nextProduct() {
  index = (index + 1) % products.length;
  updateBig();
}

function prevProduct() {
  index = (index - 1 + products.length) % products.length;
  updateBig();
}

// ghulam
document.addEventListener('DOMContentLoaded', function() {
    const findButton = document.getElementById('find-store-btn');
    const cityInput = document.getElementById('city-input');
    const categorySelect = document.getElementById('category-select');
    const successMessage = document.getElementById('success-message');

    // Button click event
    findButton.addEventListener('click', function(event) {
        event.preventDefault(); 

        const cityValue = cityInput.value.trim();
        const categoryValue = categorySelect.value;

        // Validation Check
        if (categoryValue === "" || categoryValue.includes('Choose Category')) {
            alert("Please select a product category.");
            return; 
        }
        
        if (cityValue === "") {
            alert("Please enter your city, state, or zip code.");
            return;
        }

        // If validation passes, show the success message
        successMessage.classList.remove('hidden');

        console.log(`Searching for: ${categoryValue} near ${cityValue}`);
    });
});
const modal = document.getElementById('payment-modal');
const closeBtn = modal.querySelector('.close');
const thankyouMsg = document.getElementById('thankyou-message');

document.querySelectorAll('.know-more-btn').forEach(btn=>{
  btn.addEventListener('click',()=>{
    modal.style.display='block';
    document.getElementById('payment-form').style.display='block';
    thankyouMsg.style.display='none';
  });
});

closeBtn.onclick = ()=> modal.style.display='none';
window.onclick = e=> { if(e.target==modal) modal.style.display='none'; }

document.getElementById('payment-form').addEventListener('submit', function(e){
  e.preventDefault();
  this.style.display='none';
  thankyouMsg.style.display='block';
});

            const contentDiv = document.getElementById('content-area');

            
           
        


